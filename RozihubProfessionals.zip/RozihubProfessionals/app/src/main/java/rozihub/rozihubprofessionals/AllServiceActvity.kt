package rozihub.rozihubprofessionals

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.activity_all_service_actvity.*
import rozihub.rozihubprofessionals.adapter.AllServiceAdapter

class AllServiceActvity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_all_service_actvity)
        val layoutManager: RecyclerView.LayoutManager = LinearLayoutManager(this)
        rv_all_services.layoutManager = layoutManager
        val veneuadapter= AllServiceAdapter()
        rv_all_services.adapter=veneuadapter
        rv_all_services.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                super.onScrolled(recyclerView, dx, dy)
                if (dy > 0 && floating_action_button.getVisibility() == View.VISIBLE) {
                    floating_action_button.hide()
                } else if (dy < 0 && floating_action_button.getVisibility() != View.VISIBLE) {
                    floating_action_button.show()
                }
            }
        })

        floating_action_button.setOnClickListener {

            val intent= Intent(this,AddServiceActvity::class.java)
            startActivity(intent)

        }
    }
}
