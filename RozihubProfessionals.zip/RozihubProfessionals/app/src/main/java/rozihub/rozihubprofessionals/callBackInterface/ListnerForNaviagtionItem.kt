package rozihub.rozihubprofessionals.callBackInterface

interface ListnerForNaviagtionItem {
    fun itemSelcectPosition(position:Int);
}