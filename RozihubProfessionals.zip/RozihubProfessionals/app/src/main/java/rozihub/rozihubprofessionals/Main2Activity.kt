package rozihub.rozihubprofessionals

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_main2.*

class Main2Activity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)
        newuser.setOnClickListener {
            val intent = Intent(this@Main2Activity, MainActivity::class.java)
            startActivity(intent)
        }
        forgot.setOnClickListener {
            val intent = Intent(this@Main2Activity, ForgotPasswordActvity::class.java)
            startActivity(intent)
        }
        loginbutton.setOnClickListener {
            val intent = Intent(this@Main2Activity, UserHomeActvity::class.java)
            startActivity(intent)
        }


    }
}
