package rozihub.rozihubprofessionals.fragment


import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.fragment_my_booking.view.*
import rozihub.rozihubprofessionals.MyBookingActvity
import rozihub.rozihubprofessionals.MyvenueDetailActvity

import rozihub.rozihubprofessionals.R
import rozihub.rozihubprofessionals.adapter.AllVeneueAdaptervar
import rozihub.rozihubprofessionals.callBackInterface.ListnerForNaviagtionItem


class MyBookingFragment : Fragment(), ListnerForNaviagtionItem {
    override fun itemSelcectPosition(position: Int) {
        val mainIntent = Intent(activity, MyvenueDetailActvity::class.java)
        startActivity(mainIntent)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val  view=inflater.inflate(R.layout.fragment_my_booking, container, false)
        val layoutManager: RecyclerView.LayoutManager = LinearLayoutManager(activity!!)
        view.rv_all_revenues.layoutManager = layoutManager
        val veneuadapter=AllVeneueAdaptervar(this)
        view.rv_all_revenues.adapter=veneuadapter


        return view
    }


}
