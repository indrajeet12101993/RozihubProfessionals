package rozihub.rozihubprofessionals.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import rozihub.rozihubprofessionals.R
import rozihub.rozihubprofessionals.callBackInterface.ListnerForNaviagtionItem

class AllVeneueAdaptervar (var mlistner: ListnerForNaviagtionItem) : RecyclerView.Adapter<AllVeneueAdaptervar.ViewHolder>() {
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        holder.bind( mlistner,  position)
    }

    override fun getItemCount(): Int = 10

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {

        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_venues, parent, false)

        return ViewHolder(view)
    }

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {

        fun bind(  listener: ListnerForNaviagtionItem, position: Int) {




            itemView.setOnClickListener {
                listener.itemSelcectPosition(position)
            }
        }
    }
}