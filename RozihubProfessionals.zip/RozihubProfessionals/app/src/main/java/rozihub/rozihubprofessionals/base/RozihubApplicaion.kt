package rozihub.rozihubprofessionals.base

import androidx.multidex.MultiDex
import androidx.multidex.MultiDexApplication

class RozihubApplicaion:MultiDexApplication() {


    override fun onCreate() {
        super.onCreate()
        MultiDex.install(this)
    }
}