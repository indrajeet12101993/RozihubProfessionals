package rozihub.rozihubprofessionals.constants

object AppConstants {
    internal const val REQUEST_PICK_PLACE: Int=1
}