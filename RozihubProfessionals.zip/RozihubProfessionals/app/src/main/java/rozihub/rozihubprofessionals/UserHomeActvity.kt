package rozihub.rozihubprofessionals

import android.content.Intent
import android.os.Bundle
import com.google.android.material.bottomnavigation.BottomNavigationView
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_user_home_actvity.*

class UserHomeActvity : AppCompatActivity() {

    private val mOnNavigationItemSelectedListener = BottomNavigationView.OnNavigationItemSelectedListener { item ->
        when (item.itemId) {
            R.id.navigation_home -> {
                message.setText("No Enquiry")
                return@OnNavigationItemSelectedListener true
            }
            R.id.navigation_dashboard -> {
               // message.setText(R.string.comingsoon)
                val mainIntent = Intent(this@UserHomeActvity, MyBookingActvity::class.java)
                startActivity(mainIntent)
                return@OnNavigationItemSelectedListener true
            }
            R.id.navigation_notifications -> {
                message.setText("No Payments")
                return@OnNavigationItemSelectedListener true
            }
            R.id.navigation_profile -> {
                message.setText("Upadte profile")
                return@OnNavigationItemSelectedListener true
            }
            R.id.navigation_services -> {
                val mainIntent = Intent(this@UserHomeActvity, AllServiceActvity::class.java)
                startActivity(mainIntent)
                return@OnNavigationItemSelectedListener true
            }
        }
        false
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_home_actvity)

        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener)
    }
}
