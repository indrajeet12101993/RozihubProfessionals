package rozihub.rozihubprofessionals

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_add_service_actvity.*

class AddServiceActvity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_service_actvity)
        tv_previous.setOnClickListener {
            finish()
        }
        tv_next.setOnClickListener {
            finish()
        }
    }
}
