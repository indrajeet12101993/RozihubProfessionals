package rozihub.rozihubprofessionals.fragment


import android.app.DatePickerDialog
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.DatePicker
import androidx.lifecycle.ViewModelProviders
import com.google.android.material.textfield.TextInputEditText
import kotlinx.android.synthetic.main.fragment_bussiness.view.*

import rozihub.rozihubprofessionals.R
import rozihub.rozihubprofessionals.viewmodel.SharedViewModel
import java.text.SimpleDateFormat
import java.util.*
import android.widget.TimePicker
import android.app.TimePickerDialog




class BussinessFragment : Fragment() {
    var sharedViewModel: SharedViewModel? = null

    private lateinit var et_start_time: TextInputEditText
    private lateinit var et_end_time: TextInputEditText
    private  var MTimepiker:String?=null
    var mHour: Int? = null
    var mMinute: Int? = null
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view=inflater.inflate(R.layout.fragment_bussiness, container, false)
        et_start_time=view.et_start_time
        et_end_time=view.et_end_time
        activity?.let {
            sharedViewModel = ViewModelProviders.of(it).get(SharedViewModel::class.java)
        }
        view.tv_next.setOnClickListener {
            sharedViewModel?.fragmentPositon?.postValue(1)
            replaceFragment(BussinessCatogoryFragment())
        }
        view.tv_previous.setOnClickListener {
            sharedViewModel?.fragmentPositon?.postValue(11)
            replaceFragment(BasicInfoFragment())
        }




        et_start_time.setOnClickListener {
            MTimepiker="1"
            // Get Current Time
            val c = Calendar.getInstance()
            mHour = c.get(Calendar.HOUR_OF_DAY)
            mMinute = c.get(Calendar.MINUTE)

            // Launch Time Picker Dialog
            val timePickerDialog = TimePickerDialog(activity,
                TimePickerDialog.OnTimeSetListener { view, hourOfDay, minute ->
                    et_start_time.setText(hourOfDay.toString() + ":" + minute) },
                mHour!!,
                mMinute!!,
                false
            )
            timePickerDialog.show()


        }
        et_end_time.setOnClickListener {

            // Get Current Time
            val c = Calendar.getInstance()
            mHour = c.get(Calendar.HOUR_OF_DAY)
            mMinute = c.get(Calendar.MINUTE)

            // Launch Time Picker Dialog
            val timePickerDialog = TimePickerDialog(activity,
                TimePickerDialog.OnTimeSetListener { view, hourOfDay, minute ->
                    et_end_time.setText(hourOfDay.toString() + ":" + minute) },
                mHour!!,
                mMinute!!,
                false
            )
            timePickerDialog.show()


        }




        return view
    }


    private fun replaceFragment(fragment: Fragment) {


        val transaction = activity!!.supportFragmentManager.beginTransaction()
        transaction.replace(R.id.place_holder_for_fragment, fragment)
        transaction.setTransition(androidx.fragment.app.FragmentTransaction.TRANSIT_FRAGMENT_OPEN)
        transaction.addToBackStack(null)
        transaction.commit()
    }



}
