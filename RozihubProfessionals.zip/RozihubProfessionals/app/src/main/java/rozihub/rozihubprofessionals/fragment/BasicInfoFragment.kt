package rozihub.rozihubprofessionals.fragment



import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProviders


import rozihub.rozihubprofessionals.viewmodel.SharedViewModel
import android.content.Intent
import com.google.android.libraries.places.api.Places
import com.google.android.libraries.places.api.model.Place
import com.google.android.libraries.places.widget.Autocomplete
import com.google.android.libraries.places.widget.model.AutocompleteActivityMode
import java.util.*


class BasicInfoFragment : Fragment() {
    var sharedViewModel: SharedViewModel? = null
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val view = inflater.inflate(R.layout.fragment_basic_info, container, false)
        if (!Places.isInitialized()) {
            Places.initialize(activity!!, "AIzaSyA2-W0r-PXlm9Wycii2MTy3qOIJ5ABxnDg")
        }


// Create a new Places client instance.
      //  val placesClient = Places.createClient(activity!!)
        activity?.let {
            sharedViewModel = ViewModelProviders.of(it).get(SharedViewModel::class.java)
        }
        view.et_adress.setOnClickListener {
            val fields = Arrays.asList(Place.Field.ID, Place.Field.NAME)

            val intent  =  Autocomplete.IntentBuilder(
                AutocompleteActivityMode.FULLSCREEN,fields)
                .build(activity!!);
            startActivityForResult(intent, 1)

        }

        view.tv_next.setOnClickListener {
            replaceFragment(BussinessFragment())
        }

        return view
    }

    private fun replaceFragment(fragment: Fragment) {


        val transaction = activity!!.supportFragmentManager.beginTransaction()
        transaction.replace(R.id.place_holder_for_fragment, fragment)
        transaction.setTransition(androidx.fragment.app.FragmentTransaction.TRANSIT_FRAGMENT_OPEN)
        transaction.addToBackStack(null)

        transaction.commit()
    }

  override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {

//      if (requestCode == 1) {
//          if (resultCode == RESULT_OK) {
//              val place = Autocomplete.getPlaceFromIntent(data!!)
//             // Log.i(TAG, "Place: " + place.name + ", " + place.id)
//          } else if (resultCode == AutocompleteActivity.RESULT_ERROR) {
//              // TODO: Handle the error.
//              val status = Autocomplete.getStatusFromIntent(data!!)
//             // Log.i(TAG, status.statusMessage)
//          } else if (resultCode == RESULT_CANCELED) {
//              // The user canceled the operation.
//          }
//      }
        super.onActivityResult(requestCode, resultCode, data)
    }

}
