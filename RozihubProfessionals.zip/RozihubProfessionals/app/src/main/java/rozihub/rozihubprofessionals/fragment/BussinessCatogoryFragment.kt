package rozihub.rozihubprofessionals.fragment


import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProviders
import kotlinx.android.synthetic.main.fragment_bussiness_catogory.view.*

import rozihub.rozihubprofessionals.R
import rozihub.rozihubprofessionals.UserHomeActvity
import rozihub.rozihubprofessionals.viewmodel.SharedViewModel


class BussinessCatogoryFragment : Fragment() {

    var sharedViewModel: SharedViewModel? = null
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view=inflater.inflate(R.layout.fragment_bussiness_catogory, container, false)
        activity?.let {
            sharedViewModel = ViewModelProviders.of(it).get(SharedViewModel::class.java)
        }
        view.tv_next.setOnClickListener {
            sharedViewModel?.fragmentPositon?.postValue(2)

            val intent= Intent(activity,UserHomeActvity::class.java)
            startActivity(intent)
            activity!!.finish()
        }
        view.tv_previous.setOnClickListener {
            sharedViewModel?.fragmentPositon?.postValue(22)
            replaceFragment(BussinessFragment())
        }

        // replaceFragment(BussinessCatogoryFragment())
        return view
    }

    private fun replaceFragment(fragment: Fragment) {


        val transaction = activity!!.supportFragmentManager.beginTransaction()
        transaction.replace(R.id.place_holder_for_fragment, fragment)
        transaction.setTransition(androidx.fragment.app.FragmentTransaction.TRANSIT_FRAGMENT_OPEN)
        transaction.addToBackStack(null)
        transaction.commit()
    }

}
